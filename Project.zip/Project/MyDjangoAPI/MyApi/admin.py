from django.contrib import admin
from MyApi.models import MyFile


admin.site.register(MyFile)


